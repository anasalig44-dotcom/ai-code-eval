"""Report generation utilities."""

# Report generation is handled in core.py CodeEvaluator.generate_report()
# This module provides additional export formats.

import csv
from typing import List, Dict


def export_csv(results: List[Dict], filepath: str):
    """Export evaluation results to CSV."""
    if not results:
        return

    keys = results[0].keys()
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(results)
