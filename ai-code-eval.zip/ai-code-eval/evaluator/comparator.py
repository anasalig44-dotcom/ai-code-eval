"""
Batch Evaluator - Run evaluations across multiple models and prompts.
"""

import json
from typing import List, Optional, Dict
from datetime import datetime
from .core import CodeEvaluator, ModelOutput, SxSResult


class BatchEvaluator:
    """Run batch evaluations across multiple models."""

    def __init__(self, models: List[str], dimensions: Optional[List[str]] = None):
        self.models = models
        self.evaluator = CodeEvaluator(dimensions=dimensions)
        self.results: List[SxSResult] = []

    def run(self, prompts: List[str], model_outputs: Dict[str, List[str]],
            dimensions: Optional[List[str]] = None) -> List[SxSResult]:
        """Run SxS evaluation for all model pairs across all prompts."""
        self.results = []

        for i, prompt in enumerate(prompts):
            for j in range(len(self.models)):
                for k in range(j + 1, len(self.models)):
                    model_a_name = self.models[j]
                    model_b_name = self.models[k]

                    output_a = ModelOutput(
                        model_name=model_a_name,
                        response=model_outputs.get(model_a_name, [""])[i] if i < len(model_outputs.get(model_a_name, [])) else ""
                    )
                    output_b = ModelOutput(
                        model_name=model_b_name,
                        response=model_outputs.get(model_b_name, [""])[i] if i < len(model_outputs.get(model_b_name, [])) else ""
                    )

                    result = self.evaluator.evaluate_sxs(prompt, output_a, output_b, dimensions)
                    self.results.append(result)

        return self.results

    def get_leaderboard(self) -> Dict[str, Dict]:
        """Generate a leaderboard from evaluation results."""
        stats: Dict[str, Dict] = {}

        for model in self.models:
            stats[model] = {"wins": 0, "losses": 0, "ties": 0, "avg_score": 0.0, "total_scores": []}

        for result in self.results:
            for score in result.scores_a:
                stats[result.model_a.model_name]["total_scores"].append(score.score)
            for score in result.scores_b:
                stats[result.model_b.model_name]["total_scores"].append(score.score)

            if result.winner == "tie":
                stats[result.model_a.model_name]["ties"] += 1
                stats[result.model_b.model_name]["ties"] += 1
            elif result.winner == result.model_a.model_name:
                stats[result.model_a.model_name]["wins"] += 1
                stats[result.model_b.model_name]["losses"] += 1
            else:
                stats[result.model_b.model_name]["wins"] += 1
                stats[result.model_a.model_name]["losses"] += 1

        for model in stats:
            scores = stats[model]["total_scores"]
            stats[model]["avg_score"] = sum(scores) / len(scores) if scores else 0
            del stats[model]["total_scores"]

        return dict(sorted(stats.items(), key=lambda x: (-x[1]["wins"], -x[1]["avg_score"])))

    def export_results(self, filepath: str):
        """Export results to JSON file."""
        data = {
            "metadata": {
                "models": self.models,
                "total_evaluations": len(self.results),
                "exported_at": datetime.utcnow().isoformat(),
            },
            "results": [r.to_dict() for r in self.results],
            "leaderboard": self.get_leaderboard(),
        }

        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)

    def summary(self) -> str:
        """Generate a text summary of batch results."""
        leaderboard = self.get_leaderboard()
        lines = ["=" * 50, "EVALUATION SUMMARY", "=" * 50, ""]

        for rank, (model, stats) in enumerate(leaderboard.items(), 1):
            lines.append(f"#{rank} {model}")
            lines.append(f"   Wins: {stats['wins']} | Losses: {stats['losses']} | Ties: {stats['ties']}")
            lines.append(f"   Avg Score: {stats['avg_score']:.2f}/5.0")
            lines.append("")

        return "\n".join(lines)
