"""Scoring rubrics and evaluation criteria."""

RUBRIC_DEFINITIONS = {
    "instruction_following": {
        5: "All prompt requirements fully addressed with appropriate scope",
        4: "Most requirements met, minor omissions",
        3: "Core requirements met but notable gaps",
        2: "Partially addresses the prompt, significant misses",
        1: "Does not address the prompt requirements",
    },
    "code_quality": {
        5: "Clean, idiomatic, well-structured, production-ready",
        4: "Good structure with minor style issues",
        3: "Functional but messy or inconsistent",
        2: "Poor structure, hard to read or maintain",
        1: "Broken, unreadable, or fundamentally flawed",
    },
    "tool_usage": {
        5: "Expert use of APIs, libraries, and frameworks",
        4: "Correct usage with minor inefficiencies",
        3: "Functional but non-idiomatic usage",
        2: "Incorrect or inappropriate tool usage",
        1: "Missing or completely wrong tool usage",
    },
    "testing": {
        5: "Comprehensive tests with edge cases and error paths",
        4: "Good test coverage with minor gaps",
        3: "Basic tests present, limited coverage",
        2: "Minimal or poorly written tests",
        1: "No tests or tests that don't validate anything",
    },
    "communication": {
        5: "Clear, well-organized, helpful explanations",
        4: "Good explanations with minor clarity issues",
        3: "Adequate but could be clearer",
        2: "Confusing or poorly organized response",
        1: "No explanation or incomprehensible",
    },
}
