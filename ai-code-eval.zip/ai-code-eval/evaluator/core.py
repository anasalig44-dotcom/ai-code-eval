"""
AI Code Evaluation Framework
Core evaluation engine for side-by-side model comparison.
"""

import json
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class Dimension(Enum):
    INSTRUCTION_FOLLOWING = "instruction_following"
    CODE_QUALITY = "code_quality"
    TOOL_USAGE = "tool_usage"
    TESTING = "testing"
    COMMUNICATION = "communication"


@dataclass
class EvaluationScore:
    dimension: str
    score: int  # 1-5
    justification: str
    confidence: float = 1.0

    def validate(self):
        if not 1 <= self.score <= 5:
            raise ValueError(f"Score must be 1-5, got {self.score}")
        if not 0 <= self.confidence <= 1:
            raise ValueError(f"Confidence must be 0-1, got {self.confidence}")


@dataclass
class ModelOutput:
    model_name: str
    response: str
    code_blocks: List[str] = field(default_factory=list)
    execution_time_ms: float = 0.0
    token_count: int = 0

    def extract_code_blocks(self):
        blocks = []
        lines = self.response.split("\n")
        in_block = False
        current_block = []

        for line in lines:
            if line.strip().startswith("```"):
                if in_block:
                    blocks.append("\n".join(current_block))
                    current_block = []
                    in_block = False
                else:
                    in_block = True
            elif in_block:
                current_block.append(line)

        self.code_blocks = blocks
        return blocks


@dataclass
class SxSResult:
    prompt_id: str
    model_a: ModelOutput
    model_b: ModelOutput
    scores_a: List[EvaluationScore] = field(default_factory=list)
    scores_b: List[EvaluationScore] = field(default_factory=list)
    winner: Optional[str] = None
    overall_justification: str = ""
    evaluated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def determine_winner(self) -> str:
        avg_a = sum(s.score for s in self.scores_a) / len(self.scores_a) if self.scores_a else 0
        avg_b = sum(s.score for s in self.scores_b) / len(self.scores_b) if self.scores_b else 0

        if abs(avg_a - avg_b) < 0.5:
            self.winner = "tie"
        elif avg_a > avg_b:
            self.winner = self.model_a.model_name
        else:
            self.winner = self.model_b.model_name

        return self.winner

    def to_dict(self) -> Dict:
        return {
            "prompt_id": self.prompt_id,
            "model_a": self.model_a.model_name,
            "model_b": self.model_b.model_name,
            "scores_a": [{"dim": s.dimension, "score": s.score, "justification": s.justification} for s in self.scores_a],
            "scores_b": [{"dim": s.dimension, "score": s.score, "justification": s.justification} for s in self.scores_b],
            "winner": self.winner,
            "overall_justification": self.overall_justification,
            "evaluated_at": self.evaluated_at,
        }


class CodeEvaluator:
    """Main evaluator class for AI-generated code assessment."""

    RUBRIC = {
        1: "Failing - Does not meet requirements",
        2: "Poor - Significant issues, partially functional",
        3: "Acceptable - Functional but needs improvement",
        4: "Good - Meets requirements with minor issues",
        5: "Excellent - Exceeds expectations, production-ready",
    }

    DIMENSION_CRITERIA = {
        Dimension.INSTRUCTION_FOLLOWING: [
            "Does the output address all parts of the prompt?",
            "Are constraints and requirements respected?",
            "Is the scope appropriate (not over/under-delivering)?",
        ],
        Dimension.CODE_QUALITY: [
            "Is the code readable and well-structured?",
            "Are naming conventions consistent and descriptive?",
            "Is the code efficient without premature optimization?",
            "Are design patterns used appropriately?",
        ],
        Dimension.TOOL_USAGE: [
            "Are APIs and libraries used correctly?",
            "Are imports and dependencies appropriate?",
            "Is the tool/framework idiom followed?",
        ],
        Dimension.TESTING: [
            "Are tests included when appropriate?",
            "Do tests cover edge cases?",
            "Is error handling comprehensive?",
            "Are assertions meaningful?",
        ],
        Dimension.COMMUNICATION: [
            "Is the explanation clear and concise?",
            "Are code comments helpful (not redundant)?",
            "Is the response well-organized?",
        ],
    }

    def __init__(self, dimensions: Optional[List[str]] = None):
        if dimensions:
            self.active_dimensions = [Dimension(d) for d in dimensions]
        else:
            self.active_dimensions = list(Dimension)

    def evaluate_single(self, prompt: str, output: ModelOutput, dimensions: Optional[List[str]] = None) -> List[EvaluationScore]:
        """Evaluate a single model output against a prompt."""
        dims = [Dimension(d) for d in dimensions] if dimensions else self.active_dimensions
        scores = []

        for dim in dims:
            score = self._score_dimension(prompt, output, dim)
            scores.append(score)

        return scores

    def evaluate_sxs(self, prompt: str, model_a_output: ModelOutput, model_b_output: ModelOutput, dimensions: Optional[List[str]] = None) -> SxSResult:
        """Perform side-by-side evaluation of two model outputs."""
        model_a_output.extract_code_blocks()
        model_b_output.extract_code_blocks()

        result = SxSResult(
            prompt_id=self._generate_prompt_id(prompt),
            model_a=model_a_output,
            model_b=model_b_output,
        )

        result.scores_a = self.evaluate_single(prompt, model_a_output, dimensions)
        result.scores_b = self.evaluate_single(prompt, model_b_output, dimensions)
        result.determine_winner()

        return result

    def _score_dimension(self, prompt: str, output: ModelOutput, dimension: Dimension) -> EvaluationScore:
        """Score a single dimension for a model output."""
        criteria = self.DIMENSION_CRITERIA.get(dimension, [])
        checks_passed = 0

        for criterion in criteria:
            if self._check_criterion(prompt, output, criterion):
                checks_passed += 1

        ratio = checks_passed / len(criteria) if criteria else 0
        score = max(1, min(5, round(ratio * 5)))

        return EvaluationScore(
            dimension=dimension.value,
            score=score,
            justification=f"Passed {checks_passed}/{len(criteria)} criteria checks",
            confidence=ratio,
        )

    def _check_criterion(self, prompt: str, output: ModelOutput, criterion: str) -> bool:
        """Check if a criterion is met by the output."""
        response_lower = output.response.lower()
        has_code = len(output.code_blocks) > 0

        if "tests" in criterion.lower():
            return any(kw in response_lower for kw in ["def test_", "assert ", "unittest", "pytest", "@test"])

        if "error handling" in criterion.lower():
            return any(kw in response_lower for kw in ["try:", "except", "catch", "error", "raise"])

        if "readable" in criterion.lower() or "structured" in criterion.lower():
            return has_code and len(output.code_blocks[0].split("\n")) > 2

        if "comments" in criterion.lower():
            return has_code and any("#" in block or "//" in block or "/*" in block for block in output.code_blocks)

        if "clear" in criterion.lower() or "concise" in criterion.lower():
            non_code_text = output.response
            for block in output.code_blocks:
                non_code_text = non_code_text.replace(block, "")
            return len(non_code_text.strip()) > 50

        return has_code

    def _generate_prompt_id(self, prompt: str) -> str:
        """Generate a deterministic prompt ID."""
        import hashlib
        return hashlib.md5(prompt.encode()).hexdigest()[:12]

    def generate_report(self, results: SxSResult, output: str = "report.md") -> str:
        """Generate a markdown evaluation report."""
        lines = [
            f"# Evaluation Report",
            f"",
            f"**Date**: {results.evaluated_at}",
            f"**Prompt ID**: {results.prompt_id}",
            f"",
            f"## Models Compared",
            f"- **Model A**: {results.model_a.model_name}",
            f"- **Model B**: {results.model_b.model_name}",
            f"",
            f"## Scores",
            f"",
            f"| Dimension | {results.model_a.model_name} | {results.model_b.model_name} |",
            f"|-----------|{'---:|' * 2}",
        ]

        for sa, sb in zip(results.scores_a, results.scores_b):
            lines.append(f"| {sa.dimension} | {sa.score}/5 | {sb.score}/5 |")

        avg_a = sum(s.score for s in results.scores_a) / len(results.scores_a)
        avg_b = sum(s.score for s in results.scores_b) / len(results.scores_b)
        lines.extend([
            f"| **Average** | **{avg_a:.1f}** | **{avg_b:.1f}** |",
            f"",
            f"## Winner: **{results.winner}**",
            f"",
            f"### Justification",
            f"{results.overall_justification}",
        ])

        report = "\n".join(lines)
        with open(output, "w") as f:
            f.write(report)

        return report
