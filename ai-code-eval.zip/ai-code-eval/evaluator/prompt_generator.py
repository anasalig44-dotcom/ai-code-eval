"""
Prompt Generator - Creates coding prompts from real repositories.
"""

import os
import random
from dataclasses import dataclass, field
from typing import List, Optional, Dict


@dataclass
class CodingPrompt:
    prompt_id: str
    description: str
    task_type: str
    language: str
    complexity: str
    target_file: Optional[str] = None
    context_code: str = ""
    expected_behavior: str = ""
    constraints: List[str] = field(default_factory=list)

    def to_string(self) -> str:
        parts = [self.description]
        if self.context_code:
            parts.append(f"\n### Context Code\n```{self.language}\n{self.context_code}\n```")
        if self.expected_behavior:
            parts.append(f"\n### Expected Behavior\n{self.expected_behavior}")
        if self.constraints:
            parts.append("\n### Constraints")
            for c in self.constraints:
                parts.append(f"- {c}")
        return "\n".join(parts)


class PromptGenerator:
    """Generate coding prompts from real-world repositories."""

    TASK_TYPES = ["bug_fix", "refactor", "feature", "optimization", "test_writing", "documentation"]
    COMPLEXITY_LEVELS = ["easy", "medium", "hard"]
    SUPPORTED_LANGUAGES = ["python", "javascript", "typescript", "java", "go", "cpp"]

    LANGUAGE_EXTENSIONS = {
        "python": [".py"],
        "javascript": [".js", ".jsx"],
        "typescript": [".ts", ".tsx"],
        "java": [".java"],
        "go": [".go"],
        "cpp": [".cpp", ".cc", ".h", ".hpp"],
    }

    def __init__(self, repo_path: Optional[str] = None, repo_url: Optional[str] = None):
        self.repo_path = repo_path
        self.repo_url = repo_url
        self._files_cache: Dict[str, str] = {}

    def create_prompt(self, task_type: str = "refactor", complexity: str = "medium",
                      language: str = "python", target_file: Optional[str] = None) -> CodingPrompt:
        """Create a coding prompt based on parameters."""
        if task_type not in self.TASK_TYPES:
            raise ValueError(f"Invalid task type: {task_type}. Choose from {self.TASK_TYPES}")
        if complexity not in self.COMPLEXITY_LEVELS:
            raise ValueError(f"Invalid complexity: {complexity}. Choose from {self.COMPLEXITY_LEVELS}")
        if language not in self.SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported language: {language}. Choose from {self.SUPPORTED_LANGUAGES}")

        context_code = ""
        if target_file and self.repo_path:
            context_code = self._read_file(target_file)

        prompt_id = f"{task_type}_{language}_{complexity}_{random.randint(1000, 9999)}"

        description = self._generate_description(task_type, complexity, language, target_file)
        expected = self._generate_expected_behavior(task_type, complexity)
        constraints = self._generate_constraints(task_type, complexity, language)

        return CodingPrompt(
            prompt_id=prompt_id,
            description=description,
            task_type=task_type,
            language=language,
            complexity=complexity,
            target_file=target_file,
            context_code=context_code,
            expected_behavior=expected,
            constraints=constraints,
        )

    def create_prompt_suite(self, count: int = 10, languages: Optional[List[str]] = None,
                            task_types: Optional[List[str]] = None) -> List[CodingPrompt]:
        """Create a suite of diverse coding prompts."""
        langs = languages or self.SUPPORTED_LANGUAGES
        tasks = task_types or self.TASK_TYPES
        prompts = []

        for i in range(count):
            lang = langs[i % len(langs)]
            task = tasks[i % len(tasks)]
            complexity = self.COMPLEXITY_LEVELS[i % len(self.COMPLEXITY_LEVELS)]

            prompt = self.create_prompt(task_type=task, complexity=complexity, language=lang)
            prompts.append(prompt)

        return prompts

    def scan_repository(self, language: str = "python") -> List[str]:
        """Scan repository for source files of a given language."""
        if not self.repo_path:
            return []

        extensions = self.LANGUAGE_EXTENSIONS.get(language, [])
        source_files = []

        for root, dirs, files in os.walk(self.repo_path):
            dirs[:] = [d for d in dirs if d not in {"node_modules", ".git", "__pycache__", "venv", ".venv"}]
            for f in files:
                if any(f.endswith(ext) for ext in extensions):
                    source_files.append(os.path.join(root, f))

        return source_files

    def _read_file(self, filepath: str) -> str:
        if filepath in self._files_cache:
            return self._files_cache[filepath]

        full_path = os.path.join(self.repo_path, filepath) if self.repo_path else filepath
        try:
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()
            self._files_cache[filepath] = content
            return content
        except (FileNotFoundError, UnicodeDecodeError):
            return ""

    def _generate_description(self, task_type: str, complexity: str, language: str, target_file: Optional[str]) -> str:
        templates = {
            "bug_fix": f"Fix the bug in the following {language} code. The function produces incorrect output for edge cases.",
            "refactor": f"Refactor the following {language} code to improve readability, reduce complexity, and follow best practices.",
            "feature": f"Add a new feature to the existing {language} codebase as described below.",
            "optimization": f"Optimize the following {language} code for better performance without changing its behavior.",
            "test_writing": f"Write comprehensive unit tests for the following {language} code, covering normal cases, edge cases, and error handling.",
            "documentation": f"Add clear, comprehensive documentation to the following {language} code including docstrings and inline comments.",
        }

        desc = templates.get(task_type, f"Complete the following {language} coding task.")
        if target_file:
            desc += f" Target file: `{target_file}`."
        return desc

    def _generate_expected_behavior(self, task_type: str, complexity: str) -> str:
        expectations = {
            "bug_fix": "The fixed code should handle all edge cases correctly and pass existing tests.",
            "refactor": "The refactored code should maintain identical behavior with improved structure.",
            "feature": "The new feature should integrate with existing code without breaking changes.",
            "optimization": "The optimized code should demonstrate measurable performance improvement.",
            "test_writing": "Tests should achieve high coverage and validate both success and failure paths.",
            "documentation": "Documentation should be clear, accurate, and follow language conventions.",
        }
        return expectations.get(task_type, "The solution should meet all requirements.")

    def _generate_constraints(self, task_type: str, complexity: str, language: str) -> List[str]:
        base = [
            f"Use {language} best practices and idioms",
            "Maintain backward compatibility",
            "Include error handling where appropriate",
        ]

        if complexity in ("medium", "hard"):
            base.append("Consider performance implications")
            base.append("Follow SOLID principles where applicable")

        if complexity == "hard":
            base.append("Handle concurrent/async scenarios if relevant")
            base.append("Consider memory efficiency")

        if task_type == "test_writing":
            base.append("Use the standard testing framework for the language")
            base.append("Cover at least 3 edge cases")

        return base
