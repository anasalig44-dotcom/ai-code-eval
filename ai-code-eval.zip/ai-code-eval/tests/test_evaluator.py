"""Tests for AI Code Evaluation Framework."""

import pytest
from evaluator.core import CodeEvaluator, ModelOutput, EvaluationScore, SxSResult, Dimension
from evaluator.prompt_generator import PromptGenerator, CodingPrompt
from evaluator.comparator import BatchEvaluator


class TestModelOutput:
    def test_extract_code_blocks(self):
        output = ModelOutput(
            model_name="test_model",
            response="Here is the solution:\n```python\ndef add(a, b):\n    return a + b\n```\nDone."
        )
        blocks = output.extract_code_blocks()
        assert len(blocks) == 1
        assert "def add(a, b):" in blocks[0]

    def test_extract_multiple_blocks(self):
        output = ModelOutput(
            model_name="test_model",
            response="```python\ncode1\n```\ntext\n```javascript\ncode2\n```"
        )
        blocks = output.extract_code_blocks()
        assert len(blocks) == 2

    def test_no_code_blocks(self):
        output = ModelOutput(model_name="test_model", response="Just text, no code.")
        blocks = output.extract_code_blocks()
        assert len(blocks) == 0


class TestEvaluationScore:
    def test_valid_score(self):
        score = EvaluationScore(dimension="code_quality", score=4, justification="Good code")
        score.validate()

    def test_invalid_score_too_high(self):
        score = EvaluationScore(dimension="code_quality", score=6, justification="Invalid")
        with pytest.raises(ValueError):
            score.validate()

    def test_invalid_score_too_low(self):
        score = EvaluationScore(dimension="code_quality", score=0, justification="Invalid")
        with pytest.raises(ValueError):
            score.validate()


class TestCodeEvaluator:
    def setup_method(self):
        self.evaluator = CodeEvaluator()

    def test_evaluate_single(self):
        output = ModelOutput(
            model_name="model_a",
            response="Here is the fix:\n```python\ndef solve(x):\n    # Handle edge case\n    if x < 0:\n        raise ValueError('Negative input')\n    try:\n        return x ** 2\n    except Exception as e:\n        raise\n```\nThis handles the edge case."
        )
        scores = self.evaluator.evaluate_single("Fix the bug", output)
        assert len(scores) == len(Dimension)
        assert all(1 <= s.score <= 5 for s in scores)

    def test_evaluate_sxs(self):
        output_a = ModelOutput(model_name="model_a", response="```python\ndef f(): pass\n```")
        output_b = ModelOutput(
            model_name="model_b",
            response="```python\ndef f():\n    # Implementation\n    try:\n        return True\n    except Exception:\n        return False\n```\nThis is a robust implementation."
        )
        result = self.evaluator.evaluate_sxs("Write function f", output_a, output_b)
        assert isinstance(result, SxSResult)
        assert result.winner is not None

    def test_generate_report(self, tmp_path):
        output_a = ModelOutput(model_name="A", response="```python\nx=1\n```")
        output_b = ModelOutput(model_name="B", response="```python\nx=2\n```")
        result = self.evaluator.evaluate_sxs("test", output_a, output_b)
        report_path = str(tmp_path / "report.md")
        report = self.evaluator.generate_report(result, output=report_path)
        assert "Evaluation Report" in report


class TestPromptGenerator:
    def test_create_prompt(self):
        gen = PromptGenerator()
        prompt = gen.create_prompt(task_type="refactor", complexity="medium", language="python")
        assert isinstance(prompt, CodingPrompt)
        assert prompt.task_type == "refactor"
        assert prompt.language == "python"

    def test_invalid_task_type(self):
        gen = PromptGenerator()
        with pytest.raises(ValueError):
            gen.create_prompt(task_type="invalid")

    def test_invalid_language(self):
        gen = PromptGenerator()
        with pytest.raises(ValueError):
            gen.create_prompt(language="cobol")

    def test_create_suite(self):
        gen = PromptGenerator()
        suite = gen.create_prompt_suite(count=5)
        assert len(suite) == 5

    def test_prompt_to_string(self):
        gen = PromptGenerator()
        prompt = gen.create_prompt(task_type="test_writing", language="javascript")
        text = prompt.to_string()
        assert "javascript" in text.lower()


class TestBatchEvaluator:
    def test_leaderboard(self):
        batch = BatchEvaluator(models=["model_a", "model_b"])
        prompts = ["Write a sort function"]
        outputs = {
            "model_a": ["```python\ndef sort(arr):\n    return sorted(arr)\n```"],
            "model_b": ["```python\ndef sort(arr):\n    # Bubble sort\n    for i in range(len(arr)):\n        for j in range(len(arr)-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n```"],
        }
        batch.run(prompts, outputs)
        lb = batch.get_leaderboard()
        assert "model_a" in lb
        assert "model_b" in lb

    def test_export(self, tmp_path):
        batch = BatchEvaluator(models=["a", "b"])
        prompts = ["test prompt"]
        outputs = {"a": ["```python\nx=1\n```"], "b": ["```python\ny=2\n```"]}
        batch.run(prompts, outputs)
        path = str(tmp_path / "results.json")
        batch.export_results(path)
        import json
        with open(path) as f:
            data = json.load(f)
        assert "results" in data
        assert "leaderboard" in data
